package model

type Erro struct {
	Err      error
	HttpCode int
}
